from rest_framework import generics, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Movie, Showtime, Seat, Reservation, Profile
from .serializers import MovieSerializer, ShowtimeSerializer, SeatSerializer, ReservationSerializer, ProfileSerializer
from django.core.mail import send_mail

class MovieList(generics.ListAPIView):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer
    permission_classes = [permissions.AllowAny]

class ShowtimeList(generics.ListAPIView):
    queryset = Showtime.objects.all()
    serializer_class = ShowtimeSerializer
    permission_classes = [permissions.AllowAny]

class ReserveSeats(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        showtime_id = request.data.get('showtime_id')
        seat_ids = request.data.get('seat_ids')
        showtime = Showtime.objects.get(id=showtime_id)
        reservation = Reservation.objects.create(user=request.user, showtime=showtime)
        reservation.seats.set(Seat.objects.filter(id__in=seat_ids))
        for seat in reservation.seats.all():
            seat.is_reserved = True
            seat.save()
        reservation.save()

        send_mail(
            'Booking Confirmed',
            f'Your seats for {showtime.movie.title} at {showtime.start_time} are booked.',
            'noreply@cinema.com',
            [request.user.email],
        )

        return Response({'message': 'Reservation successful!'})

class MyProfile(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile = Profile.objects.get(user=request.user)
        reservations = Reservation.objects.filter(user=request.user)
        return Response({
            'profile': ProfileSerializer(profile).data,
            'reservations': ReservationSerializer(reservations, many=True).data
        })
